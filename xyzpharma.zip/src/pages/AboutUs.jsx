import {Box} from "@mui/material";

const AboutUs = () => {
    return (
        <div className="about-page">
            <Box className="about-page-section" sx={{width: '100%'}}>
                <h1 className="about-page-header">About XYZPharma</h1>
                <hr className="about-page-hr"/>
                <p className="about-page-text">
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore
                    et dolore magna aliqua. Tortor consequat id porta nibh venenatis cras. Laoreet id donec ultrices
                    tincidunt arcu non sodales neque sodales. Massa ultricies mi quis hendrerit dolor magna eget.
                    Vestibulum lorem sed risus ultricies tristique nulla aliquet. Convallis tellus id interdum velit.
                    Cras pulvinar mattis nunc sed blandit libero volutpat sed cras. Faucibus vitae aliquet nec
                    ullamcorper sit amet risus nullam. Netus et malesuada fames ac turpis egestas maecenas. Nibh tortor
                    id aliquet lectus proin nibh nisl condimentum. In aliquam sem fringilla ut morbi tincidunt augue
                    interdum velit. Id venenatis a condimentum vitae sapien pellentesque. Pharetra diam sit amet nisl
                    suscipit. Etiam tempor orci eu lobortis elementum nibh tellus molestie. Placerat orci nulla
                    pellentesque dignissim enim sit.
                </p>
            </Box>

            <Box className="about-page-section" sx={{width: '100%'}}>
                <h1 className="about-page-header">Awards</h1>
                <hr className="about-page-hr"/>
                <ul className="about-page-text">
                    <li>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut
                        labore et dolore magna aliqua.
                    </li>
                    <li>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut
                        labore et dolore magna aliqua.
                    </li>
                    <li>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut
                        labore et dolore magna aliqua.
                    </li>
                    <li>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut
                        labore et dolore magna aliqua.
                    </li>
                    <li>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut
                        labore et dolore magna aliqua.
                    </li>
                    <li>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut
                        labore et dolore magna aliqua.
                    </li>
                </ul>
            </Box>

            <Box className="about-page-section" sx={{width: '100%'}}>
                <h1 className="about-page-header">Contact Us</h1>
                <hr className="about-page-hr"/>
                <div className="contact-section">
                    <div className="contact-address-section">
                        <span>Head Office: </span>
                        <span>XYZPharma</span>
                        <span>Pharma House, MountValley</span>
                        <span>SH Marg, Mumbai</span>
                        <span>400201</span>
                    </div>
                    <div className="contact-working-hours-section">
                        <span>Business Hours: </span>
                        <span>24x7</span>
                        <span>Contact before visiting: 90105126406</span>
                    </div>
                </div>
            </Box>
        </div>
    );
};

export default AboutUs;