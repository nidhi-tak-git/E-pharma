import {Button, TextField, Typography} from "@mui/material";
import ProductCard from "../components/ProductCard.jsx";
import RemoveShoppingCartIcon from '@mui/icons-material/RemoveShoppingCart';
import {useEffect, useState} from "react";
import {getAllProducts} from "../util/apiCalls.js";
import "../assets/page.css";

const Products = () => {
    const [inputValue, setInputValue] = useState("");
    const [initialMedicineList, setInitialMedicineList] = useState([]);
    const [medicines, setMedicines] = useState([]);

    const onFormSubmit = (event) => {
        event.preventDefault();
        window.alert(inputValue);
    };

    const getMedicinesForFilter = (value) => {
        return initialMedicineList.filter(product => String(product.title).toLocaleLowerCase().includes(value.toLocaleLowerCase()));
    };

    const onChange = async (event) => {
        setInputValue(event.target.value);
        console.log(event.target.value.trim());
        if(event.target.value.trim() === "") {
            setMedicines(initialMedicineList)
        } else {
            const medicineList = getMedicinesForFilter(event.target.value);
            setMedicines(medicineList);
        }
    };

    const fetchData = async () => {
        const data = await getAllProducts();
        setInitialMedicineList(data);
        setMedicines(data);
    };

    useEffect(() => {
        fetchData().then();
    }, []);

    return (
        <div className={"dashboard-page"}>
            <h1 className="product-title">Products </h1>
            <form className="dashboard-form" onSubmit={onFormSubmit}>
                <TextField
                    required
                    id="outlined-required"
                    label="Product Name"
                    value={inputValue}
                    onChange={onChange}
                />
                <Button variant="contained" type="submit">Search</Button>
            </form>
            <div className="product-card-container">
                {
                    medicines.length > 0 ?
                        medicines.map((medicine, item) => {
                            return (
                                <ProductCard key={item} medicine={medicine}/>
                            )
                        }) : <><RemoveShoppingCartIcon/> Sorry this medicine not manufactured by XYZPharma</>
                }
            </div>
        </div>
    );
};

export default Products;
