import {Button, Chip, FormControl, InputLabel, MenuItem, Select, Stack} from "@mui/material";
import {useEffect, useState} from "react";
import {getFirstFiveQuarterDetail, getQuarterDetail} from "../util/apiCalls.js";
import {DatePicker, LocalizationProvider} from "@mui/x-date-pickers";
import {AdapterDayjs} from "@mui/x-date-pickers/AdapterDayjs";
import {DemoContainer} from "@mui/x-date-pickers/internals/demo";
import dayjs from "dayjs";
import InvestorTable from "../components/InvestorTable.jsx";

const Investor = () => {
    const [chips, setChips] = useState([]);
    const [quarter, setQuarter] = useState("");
    const [financialYear, setFinancialYear] = useState(null);
    const [tableData, setTableData] = useState([]);

    const handleChipClick = (quarter) => {
        const quarterDetails = quarter.split(" ");
        setQuarter(quarterDetails[0]);
        setFinancialYear(dayjs((quarterDetails[1])))
    };

    const onQuarterChange = (event) => {
        setQuarter(event.target.value);
    };

    const onFinancialYearChange = (value) => {
        setFinancialYear(value);
    };

    const onFormSubmit = async (event) => {
        event.preventDefault();
        console.log(quarter, financialYear?.$y);
        const data = await getQuarterDetail(`${quarter} ${financialYear.$y}`);
        setTableData(data);
    };

    const getChipDetails = async () => {
        const data = await getFirstFiveQuarterDetail();
        setChips(data);
    };

    useEffect(() => {
        getChipDetails().then();
    }, []);

    return (
        <div className="investor-page">
            <h1 className="product-title">Quarter Details </h1>
            <div className="quarter-details">
                <span>Quarter Details available of: </span>
                <Stack direction="row" spacing={1}>
                    {
                        chips.map(chip => {
                            return (
                                <Chip key={chip.id} label={chip.quarter} variant="outlined"
                                      onClick={() => handleChipClick(chip.quarter)}/>
                            );
                        })
                    }
                </Stack>
            </div>

            <form className="dashboard-form" onSubmit={onFormSubmit}>
                <FormControl sx={{minWidth: "250px", paddingTop: "8px"}}>
                    <InputLabel id="simple-select-label" sx={{paddingTop: 1}}>Quarter</InputLabel>
                    <Select
                        labelId="simple-select-label"
                        id="simple-select"
                        value={quarter}
                        label="Quarter"
                        onChange={onQuarterChange}
                        size="medium"
                    >
                        <MenuItem value={"Q1"}>Q1</MenuItem>
                        <MenuItem value={"Q2"}>Q2</MenuItem>
                        <MenuItem value={"Q3"}>Q3</MenuItem>
                        <MenuItem value={"Q4"}>Q4</MenuItem>
                    </Select>
                </FormControl>
                <LocalizationProvider dateAdapter={AdapterDayjs}>
                    <DemoContainer components={['DatePicker']}>
                        <DatePicker label="Financial Year"
                                    format="YYYY"
                                    views={['year']}
                                    value={financialYear}
                                    onChange={onFinancialYearChange}
                        />
                    </DemoContainer>
                </LocalizationProvider>
                <Button variant="contained" type="submit" sx={{paddingTop: "8px"}}>Search</Button>
            </form>

            {
                tableData.length > 0 ?
                <div className="financial-table">
                    <InvestorTable tableData={tableData} />
                </div> : <></>
            }
        </div>
    );
};

export default Investor;