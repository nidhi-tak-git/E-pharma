const Error = () => {
    return (
        <div style={{width: "100vw", display: "flex", justifyContent: "center", alignItems: "center"}}>
            <h1>404 - Page Not Found</h1>
        </div>
    );
};

export default Error;