import {Card, CardActions, CardContent, Typography} from "@mui/material";
import {useEffect, useState} from "react";
import {useParams} from "react-router-dom";
import {getProductById} from "../util/apiCalls.js";

const ProductDetail = () => {
    const [medicine, setMedicine] = useState({});
    const medicineId = useParams();

    const getProductDetails = async () => {
        const medicine = await getProductById(medicineId.id);
        setMedicine((medicine));
    };

    useEffect(() => {
        getProductDetails().then();
    }, []);

    console.log(medicine);

    return (
        <div className={"product-detail-card-container"}>
            {Object.keys(medicine).length > 0 ?
                <Card variant="outlined" className={"product-detail-card"}>
                    <CardContent style={{padding: 0}}>
                        <Typography className={"product-detail-card-header"} component="div">
                            {medicine.title}
                        </Typography>
                        <div className="product-detail-card-section">
                            <Typography component="div" className={"product-detail-card-body-title"}>
                                Salt Composition:
                            </Typography>
                            <Typography component="div" className={"product-detail-card-body-subtitle"}>
                                {medicine.composition}
                            </Typography>
                        </div>
                        <div className="product-detail-card-section">
                            <Typography component="div" className={"product-detail-card-body-title"}>
                                About:
                            </Typography>
                            <Typography component="div" className={"product-detail-card-body-subtitle"}>
                                {medicine.about}
                            </Typography>
                        </div>

                        <div className="product-detail-card-section">
                            <Typography component="div" className={"product-detail-card-body-title"}>
                                Use:
                            </Typography>
                            <Typography component="div" className={"product-detail-card-body-subtitle"}>
                                {medicine.productUse}
                            </Typography>
                        </div>

                        <div className="product-detail-card-section">
                            <Typography component="div" className={"product-detail-card-body-title"}>
                                Side Effects:
                            </Typography>
                            <Typography component="div" className={"product-detail-card-body-subtitle"}>
                                {medicine.sideEffects}
                            </Typography>
                        </div>
                    </CardContent>
                    <CardActions className={"product-detail-card-footer"}>
                        Note: Consume product according to prescription
                    </CardActions>
                </Card> :
                <div style={{width: "100%", textAlign: "center", fontFamily: "sans-serif", fontSize: "2rem"}}>Product Details Not Found</div>
            }
        </div>
    );
};

export default ProductDetail;