import "../assets/page.css";
import {Box, Button, Container, FormControl, InputLabel, MenuItem, Select, TextField} from "@mui/material";
import {useEffect, useState} from "react";
import {getAllProducts} from "../util/apiCalls.js";
import {useNavigate} from "react-router-dom";

const Dashboard = () => {
    const navigate = useNavigate();

    const [inputValue, setInputValue] = useState("");
    const [productList, setProductList] = useState([]);

    const onChange = (event) => {
        setInputValue(event.target.value);
    };

     const onFormSubmit = (event) => {
         event.preventDefault();
         navigate(`/product/${inputValue}`);
     };

     const fetchProducts = async () => {
         const data = await getAllProducts();
         setProductList(data);
     };

    useEffect(() => {
        fetchProducts().then();
    }, []);

    return (
        <Container>
            <Box sx={{ minWidth: "300px", maxWidth: "320px", width: "100%", margin: "auto", display: "flex", gap: "1rem", flexWrap: "nowrap", alignItems: "center"}}>
                <FormControl fullWidth>
                    <InputLabel id="demo-simple-select-label">Select Product</InputLabel>
                    <Select
                        labelId="simple-select-label"
                        id="simple-select"
                        value={inputValue}
                        label="Product"
                        onChange={onChange}
                    >
                        {
                            productList.map(product => {
                                return (
                                    <MenuItem key={product.id} value={product.id}>{product.title}</MenuItem>
                                );
                            })
                        }
                    </Select>
                </FormControl>
                <Button variant="contained" onClick={onFormSubmit} sx={{padding: "5px 20px", height: "2.5rem"}} type="button">Search</Button>
            </Box>
        </Container>
    );
};

export default Dashboard;
