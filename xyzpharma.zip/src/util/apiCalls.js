export const getAllProducts = async () => {
    try {
        const response = await fetch("http://localhost:8081/products/getAllProducts");
        if (response.ok) {
            const data = await response.json();
            console.log("All products", data);
            return data;
        } else {
            throw new Error(response);
        }
    } catch (error) {
        console.log(error);
        return [];
    }
};

export const getProductById = async (productId) => {
    try {
        const response = await fetch(`http://localhost:8081/products/getProduct/${productId}`);
        if (response.ok) {
            const data = await response.json();
            console.log("Fetched product", data);
            return data;
        } else {
            throw new Error(response);
        }
    } catch (error) {
        console.log(error);
        return {};
    }
};

export const getFirstFiveQuarterDetail = async () => {
    try {
        const response = await fetch("http://localhost:8082/investor/getFirstFiveFinancialDetails");
        if (response.ok) {
            const data = await response.json();
            console.log("Investor Details", data);
            return data;
        } else {
            throw new Error(response);
        }
    } catch (error) {
        console.log(error);
        return [];
    }
};

export const getQuarterDetail = async (quarter) => {
    try {
        const response = await fetch(`http://localhost:8082/investor/getFinancialDetail/${quarter}`);
        if (response.ok) {
            const data = await response.json();
            console.log("Quarter Detail", data);
            return data;
        } else {
            throw new Error(response);
        }
    } catch (error) {
        console.log(error);
        return [];
    }
};