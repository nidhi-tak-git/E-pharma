import Navbar from "./components/navbar.jsx";

import './App.css'
import {BrowserRouter, Route, Routes} from "react-router-dom";
import Dashboard from "./pages/Dashboard.jsx";
import Products from "./pages/Products.jsx";
import Investor from "./pages/Investor.jsx";
import AboutUs from "./pages/AboutUs.jsx";
import Error from "./pages/Error.jsx";
import {Container} from "@mui/material";
import ProductDetail from "./pages/ProductDetail.jsx";

const App = () => {

    return (
        <>
            <Navbar/>
            <Container>
                <div style={{marginTop: "5rem"}}>
                    <BrowserRouter>
                        <Routes>
                            <Route path="/dashboard" element={<Dashboard/>}/>
                            <Route path="/product" element={<Products/>}/>
                            <Route path="/investor" element={<Investor/>}/>
                            <Route path="/aboutus" element={<AboutUs/>}/>
                            <Route path="/product/:id" element={<ProductDetail/>}/>
                            <Route path="/*" element={<Error/>}/>
                        </Routes>
                    </BrowserRouter>
                </div>
            </Container>
        </>
    );
}

export default App
