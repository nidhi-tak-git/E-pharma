import {Button, Card, CardActions, CardContent, CardMedia, Typography} from "@mui/material";
import PropTypes from "prop-types";
import {useNavigate} from "react-router-dom";

const ProductCard = (props) => {
    const {medicine} = props;
    const navigate = useNavigate();

    const getProductDetail = () => {
        navigate(`/product/${medicine.id}`)
    };

    return (
        <div className="product-card">
            <Card sx={{ maxWidth: 345, minWidth: 300, width: "100%" }}>
                <div className={"product-card-head"}>
                    <CardMedia
                        component="img"
                        alt="medicine Image"
                        height="180"
                        className={"product-card-image"}
                        image="/medicine.jpg"
                    />
                    <Typography className="product-card-title" gutterBottom variant="h5" component="div">
                        {medicine?.title}
                    </Typography>
                </div>
                <CardContent>
                    <Typography variant="body1" color="text.secondary" style={{ marginLeft: "1.5rem" }}>
                        <ul>
                            <li>
                                Use: {medicine?.productUse}
                            </li>
                        </ul>
                    </Typography>
                </CardContent>
                <CardActions>
                    <Button size="small" sx={{ marginLeft: "1rem" }} onClick={getProductDetail}>See Details</Button>
                </CardActions>
            </Card>
        </div>
    );
};

ProductCard.propTypes = {
    medicine: {
        id: PropTypes.number,
        title: PropTypes.string,
        productUse: PropTypes.string
    }
}

export default ProductCard;