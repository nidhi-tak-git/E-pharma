import {Box} from "@mui/material";
import {DataGrid} from "@mui/x-data-grid";
import PropTypes from "prop-types";

const InvestorTable = ({tableData}) => {
    const columns = [
        { field: 'id', headerName: 'ID', width: 90 },
        {
            field: 'quarter',
            headerName: 'Quarter',
            width: 120,
        },
        {
            field: 'sales',
            headerName: 'Sales',
            width: 120,
        },
        {
            field: 'otherIncome',
            headerName: 'Other Income',
            width: 120,
        },
        {
            field: 'grossProfit',
            headerName: 'Gross Profit',
            width: 120,
        },
        {
            field: 'depreciation',
            headerName: 'Depreciation',
            width: 120,
        },
        {
            field: 'interest',
            headerName: 'Interest',
            width: 120,
        },
        {
            field: 'tax',
            headerName: 'Tax',
            width: 120,
        },
        {
            field: 'netProfit',
            headerName: 'Net Profit',
            width: 120,
        }
    ];

    return (
        <>
            <Box sx={{ height: 400, width: '100%' }}>
                <DataGrid
                    rows={tableData}
                    columns={columns}
                    initialState={{
                        pagination: {
                            paginationModel: {
                                pageSize: 5,
                            },
                        },
                    }}
                    pageSizeOptions={[5]}
                    disableRowSelectionOnClick
                />
            </Box>
        </>
    );
};

InvestorTable.propTypes = {
    tableData: PropTypes.array
}

export default  InvestorTable;