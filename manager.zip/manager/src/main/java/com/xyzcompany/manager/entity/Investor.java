package com.xyzcompany.manager.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name = "Investor")
public class Investor {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID")
    private int id;
    @Column(name = "QUARTER")
    private String quarter;
    @Column(name = "SALES")
    private int sales;
    @Column(name = "OTHER INCOME")
    private double otherIncome;
    @Column(name = "GROSS PROFIT")
    private double grossProfit;
    @Column(name = "DEPRECIATION")
    private double depreciation;
    @Column(name = "INTEREST")
    private double interest;
    @Column(name = "TAX")
    private double tax;
    @Column(name = "NET PROFIT")
    private double netProfit;

    @Override
    public String toString() {
        return "Investor [id=" + id + ", quarter=" + quarter + ", sales=" + sales + ", otherIncome=" + otherIncome + ", grossProfit=" + grossProfit + ", depreciation=" + depreciation + ", interest=" + interest + ", tax=" + tax + ", netProfit=" + netProfit;
    }
}
