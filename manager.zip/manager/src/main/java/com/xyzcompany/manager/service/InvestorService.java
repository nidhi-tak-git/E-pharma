package com.xyzcompany.manager.service;

import com.xyzcompany.manager.entity.Investor;
import com.xyzcompany.manager.repository.InvestorRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.awt.print.Pageable;
import java.util.List;

@Service
@Slf4j
public class InvestorService {
    private final InvestorRepository investorRepository;

    public InvestorService(InvestorRepository investorRepository) {
        this.investorRepository = investorRepository;
    }

    public ResponseEntity<Integer> addFinancialDetails(Investor investor) {
        log.info(investor.toString());
        try {
            Investor save = investorRepository.save(investor);
            log.info(save.toString());
            return ResponseEntity.ok(save.getId());
        } catch (Exception exception) {
            log.info(exception.getMessage());
        }
        return ResponseEntity.badRequest().build();
    }

    public ResponseEntity<List<Investor>> getFinancialDetail(String quarter) {
        try {
            List<Investor> investorList = investorRepository.findByQuarter(quarter);
            investorList.forEach(investor -> log.info(investor.toString()));
            return ResponseEntity.ok(investorList);
        } catch (Exception exception) {
            log.info(exception.getMessage());
        }
        return ResponseEntity.noContent().build();
    }

    public ResponseEntity<List<Investor>> getFirstFiveFinancialDetails() {
        try {
            PageRequest pageRequest = PageRequest.of(0, 5);
            List<Investor> investorList = investorRepository.findByOrderByIdAsc(pageRequest);
            return ResponseEntity.ok(investorList);
        } catch (Exception exception) {
            log.info(exception.getMessage());
        }
        return ResponseEntity.notFound().build();
    }

}
