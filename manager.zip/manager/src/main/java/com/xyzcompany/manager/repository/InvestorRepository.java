package com.xyzcompany.manager.repository;

import com.xyzcompany.manager.entity.Investor;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface InvestorRepository extends CrudRepository<Investor, Integer> {
    List<Investor> findByQuarter(String quarter);

    List<Investor> findByOrderByIdAsc(PageRequest pageRequest);
}
