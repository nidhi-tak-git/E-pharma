package com.xyzcompany.manager.controller;

import com.xyzcompany.manager.entity.Investor;
import com.xyzcompany.manager.service.InvestorService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin
@RequestMapping("/investor")
public class InvestorController {
    private final InvestorService investorService;

    public InvestorController(InvestorService investorService) {
        this.investorService = investorService;
    }

//    ADD FINANCIAL DETAILS
    @PostMapping("/addFinancialDetails")
    public ResponseEntity<Integer> addFinancialDetails(@RequestBody Investor investor) {
        return investorService.addFinancialDetails(investor);
    }

//    GET FINANCIAL DETAIL
    @GetMapping("/getFinancialDetail/{financialQuarterYearDetail}")
    public ResponseEntity<List<Investor>> getFinancialDetail(@PathVariable String financialQuarterYearDetail) {
        return investorService.getFinancialDetail(financialQuarterYearDetail);
    }

    @GetMapping("/getFirstFiveFinancialDetails")
    public ResponseEntity<List<Investor>> getFirstFiveFinancialDetails() {
        return investorService.getFirstFiveFinancialDetails();
    }
}
